# Mẫu tóm tắt có nguồn

## Mục tiêu cần quyết định
[Một câu mô tả việc cần người phụ trách quyết định]

## Dữ kiện từ tài liệu
| Ý chính | Nguồn file | Trích ý hoặc vị trí kiểm tra |
|---|---|---|
| [Dữ kiện] | [INPUT/ten-file.md] | [Mục/ý trong nguồn] |

## Điều chưa biết và câu hỏi cần xác nhận
- [Điều thiếu trong nguồn; không tự đoán]

## Đề xuất bước tiếp theo
- [Đề xuất của agent, không gắn nhãn dữ kiện]

## Tự kiểm trước bàn giao
- Đọc đúng các nguồn được giao; từng kết luận quan trọng có căn cứ.
- Giữ nguyên INPUT/REFERENCE, không gửi hoặc đăng nội dung.
- Bản dự kiến được người dùng xem trước khi lưu; mở lại sau khi lưu.