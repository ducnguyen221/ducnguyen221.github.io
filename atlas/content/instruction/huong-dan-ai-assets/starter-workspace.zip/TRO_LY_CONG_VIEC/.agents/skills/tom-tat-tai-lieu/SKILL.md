---
name: tom-tat-tai-lieu
description: Summarizes a named set of business documents with source paths, unknowns, and next questions. Use when preparing a decision summary from files in a workspace.
---

# Tóm tắt tài liệu có nguồn

1. Đọc README.md để hiểu mục tiêu và phạm vi.
2. Chỉ mở file nguồn người dùng nêu; ghi lại đường dẫn.
3. Tách thông tin trong file, đề xuất và điều chưa biết.
4. Gắn tên file nguồn cho mỗi kết luận chính; không biến suy luận thành fact.
5. Hỏi người dùng nếu nguồn mâu thuẫn hoặc thiếu dữ kiện ảnh hưởng quyết định.
6. Hiện bản nháp trước; chờ người dùng duyệt rồi mới lưu vào OUTPUT/.
7. Đọc `references/mau-tom-tat.md` và tự kiểm trước khi bàn giao.
8. Không sửa nguồn, gửi, đăng, chia sẻ, move hoặc xóa file.