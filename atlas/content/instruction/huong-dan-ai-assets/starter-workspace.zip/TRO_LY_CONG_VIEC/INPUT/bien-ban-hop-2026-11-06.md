# Biên bản họp giả lập — 06/11/2026

**Dự án:** thử nội dung giới thiệu Trà Sen Sớm của Xưởng Trà Mộc (hư cấu)

## Trao đổi
- Nhóm muốn thử một nội dung giới thiệu sản phẩm trong ba tuần.
- Hai kênh được cân nhắc: email và fanpage.
- Chưa có ngân sách được duyệt.
- Chưa có số liệu chuyển đổi hoặc khách hàng thực.

## Việc cần xác nhận
- Ai duyệt nội dung trước khi gửi/đăng.
- Ngân sách và thời gian bắt đầu.
- Chỉ số nào có thể đo trong từng kênh.

## Quyết định
Chưa chốt lịch phát hành. Không đăng hoặc gửi nội dung khi chưa được người phụ trách duyệt.