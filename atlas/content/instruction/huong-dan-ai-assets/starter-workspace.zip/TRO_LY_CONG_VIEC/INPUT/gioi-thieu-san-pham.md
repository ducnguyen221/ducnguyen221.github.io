# Giới thiệu sản phẩm — Xưởng Trà Mộc

> Dữ liệu giả lập cho bài tập. Không đại diện cho doanh nghiệp thật.

Xưởng Trà Mộc là thương hiệu hư cấu bán trà lá đóng gói tại Việt Nam.

## Sản phẩm trong bài tập
- Tên: Trà Sen Sớm
- Quy cách: hộp 20 túi lọc
- Giá niêm yết giả định: 120.000 đồng/hộp
- Mô tả được phép dùng: trà hương sen dịu, đóng gói tiện để pha tại nhà hoặc nơi làm việc

## Chưa xác nhận
- Chưa có số liệu kiểm nghiệm thành phần.
- Chưa có chứng nhận hữu cơ.
- Chưa có dữ liệu khách hàng hoặc đánh giá thật.