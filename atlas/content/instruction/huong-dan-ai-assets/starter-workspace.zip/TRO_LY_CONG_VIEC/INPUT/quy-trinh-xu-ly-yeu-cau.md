# Quy trình xử lý yêu cầu — bản nháp giả lập

> Quy trình hư cấu để luyện tập; chưa phải hướng dẫn vận hành thật.

1. Ghi nhận nội dung và ngày nhận yêu cầu.
2. Phân loại: hỏi thông tin, đổi đơn, phản hồi chất lượng hoặc yêu cầu khác.
3. Nếu thiếu mã đơn hoặc mô tả, hỏi người gửi bổ sung; không đoán.
4. Chuyển trường hợp chất lượng cho người phụ trách xem xét.
5. Chỉ thông báo kết quả sau khi người phụ trách xác nhận.
6. Lưu bản tóm tắt đã duyệt trong hồ sơ dự án.

Không đưa dữ liệu cá nhân vào bài tập này.