# Yêu cầu công việc giả lập

Hãy chuẩn bị bản tóm tắt một trang để người phụ trách quyết định có nên thử nội dung giới thiệu Trà Sen Sớm trong ba tuần hay không.

Bản tóm tắt cần có:
- Mục tiêu dự kiến và đối tượng cần làm rõ.
- Hai kênh đang cân nhắc.
- Những thông tin đã có và nguồn của chúng.
- Những điều chưa được xác nhận.
- Các câu hỏi người phụ trách cần quyết định.

Không tự viết nội dung quảng cáo hoàn chỉnh, không gửi email, không đăng fanpage, không tự đặt ngân sách hoặc tuyên bố về tác dụng/chứng nhận sản phẩm.