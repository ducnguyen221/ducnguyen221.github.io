# AGENTS.md — Trợ lý công việc

## Bắt đầu từ đâu
- Đọc `README.md` trước khi làm để hiểu mục tiêu, cây folder và đầu việc.
- Với mỗi task, chỉ đọc file được nêu tên; kiểm tra tên và đường dẫn.
- `INPUT/` là nguồn gốc cần giữ. `REFERENCE/` chỉ chứa nguồn người phụ trách đã xác nhận.

## Tìm và lưu
| Khi cần... | Tìm ở... | Lưu ở... |
|---|---|---|
| Đọc yêu cầu mới/bản gốc | `INPUT/` | Không sửa; không tự move/xóa |
| Dùng thông tin đã xác nhận | `REFERENCE/` | Chỉ sau khi người phụ trách duyệt |
| Tiếp tục bản nháp | `WORKING/` | Bản chưa duyệt |
| Lấy kết quả | `OUTPUT/` | Kết quả tự kiểm; không ghi đè |
| Tra phiên bản cũ | `ARCHIVE/` | Chỉ lưu sau khi được duyệt |

## Tên file và phạm vi
- Tên file dùng chữ thường không dấu, các từ cách bằng dấu gạch ngang. Báo cáo có ngày và phiên bản: `tom-tat-cong-viec-2026-11-06-v01.md`; nếu đã có v01 thì dùng v02, không ghi đè. Tên hệ thống giữ nguyên: README.md, AGENTS.md, SKILL.md và INDEX.md.
- Chỉ làm trong workspace đang mở; giữ nguyên `INPUT/` và `REFERENCE/`.
- Không tự gửi, đăng, chia sẻ, di chuyển hoặc xóa file.
- Nếu cần quyền ngoài workspace, dừng và giải thích; không tìm cách mở rộng quyền.

## Chất lượng và tự kiểm
- Tách thông tin trong nguồn, đề xuất và điều chưa biết.
- Ghi tên/đường dẫn nguồn cho từng ý chính; nêu điều chưa biết và bước tiếp theo, không bịa dữ kiện.
- Trước khi ghi, nêu file và vị trí dự kiến để tôi duyệt.
- Sau khi ghi, mở lại file, so với yêu cầu và nguồn; báo file đã đọc/tạo/sửa và điều còn cần kiểm tra.
- Với file cũ, chỉ đề xuất ARCHIVE; không tự chuyển hoặc xóa.