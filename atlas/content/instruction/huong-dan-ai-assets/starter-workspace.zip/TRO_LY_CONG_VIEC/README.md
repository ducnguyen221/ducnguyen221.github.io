# Trợ lý công việc — Xưởng Trà Mộc (dữ liệu giả lập)

## Mục tiêu
Thực hành phân loại tài liệu và tạo bản tóm tắt có dẫn nguồn. Không phải dự án của doanh nghiệp thật.

## Bản đồ folder
- `INPUT/`: tài liệu mới; giữ nguyên bản gốc.
- `REFERENCE/`: thông tin/quy trình đã được người phụ trách xác nhận.
- `WORKING/`: bản nháp đang làm, chưa phải nguồn chuẩn.
- `OUTPUT/`: kết quả để người phụ trách xem và duyệt.
- `ARCHIVE/`: phiên bản cũ còn giá trị tra cứu, không phải thùng rác.
- `AGENTS.md`: cách agent làm việc trong workspace.

## Đầu việc hiện tại
Tóm tắt yêu cầu giả lập trong `INPUT/yeu-cau-cong-viec.md`; chỉ lưu sau khi tôi xem bản nháp.