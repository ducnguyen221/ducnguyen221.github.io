# Brain — mục lục tri thức giả lập

> Bài tập, không phải thông tin về doanh nghiệp thật.

## Tìm theo câu hỏi
- Nguồn sản phẩm và điều chưa xác nhận: `10_SOURCES/nguon-gioi-thieu-san-pham.md`
- Có thể mô tả gì về Trà Sen Sớm: `20_KNOWLEDGE/mo-ta-tra-sen.md`
- Cách tóm tắt tài liệu có nguồn: `30_PLAYBOOKS/tom-tat-tai-lieu.md`

## Truy nguyên
Ghi chú tri thức phải trỏ về ghi chú nguồn và file gốc. Nếu không tìm thấy đường về nguồn, đừng khẳng định là fact.