# Mô tả Trà Sen Sớm — tri thức từ ví dụ giả lập

Trong bài học, có thể mô tả đây là trà hương sen dịu, hộp 20 túi lọc tiện pha tại nhà hoặc nơi làm việc. Không thêm tuyên bố về tác dụng sức khỏe.

Về thành phần/chứng nhận, nguồn ghi chưa có số liệu kiểm nghiệm thành phần và chưa có chứng nhận hữu cơ. Không suy ra tình trạng của chứng nhận khác.

[Ghi chú nguồn](../10_SOURCES/nguon-gioi-thieu-san-pham.md).