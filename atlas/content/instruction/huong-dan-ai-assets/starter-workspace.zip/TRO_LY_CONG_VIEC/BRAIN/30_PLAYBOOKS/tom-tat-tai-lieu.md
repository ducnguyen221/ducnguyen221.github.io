# Quy trình nghiệp vụ: tóm tắt có nguồn

1. Chốt câu hỏi và các file được phép dùng.
2. Tách dữ kiện có nguồn, điều chưa biết và đề xuất.
3. Gắn nguồn vào ý chính, kiểm lại các con số và phủ định.
4. Để người phụ trách xem nội dung rồi mới lưu bản bàn giao.

Đây là quy trình cho người tra cứu. Khi muốn agent tự nhận diện một skill, dùng [SKILL.md](../../.agents/skills/tom-tat-tai-lieu/SKILL.md) nằm ngoài BRAIN.