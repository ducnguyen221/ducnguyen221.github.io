# Nguồn: giới thiệu sản phẩm — giả lập

- Nguồn gốc: [INPUT/gioi-thieu-san-pham.md](../../INPUT/gioi-thieu-san-pham.md).
- Ngày đọc: 2026-11-06. Đây là dữ liệu bài học, không phải doanh nghiệp thật.
- Nguồn ghi tên Trà Sen Sớm, hộp 20 túi lọc và giá giả định 120.000 đồng/hộp.
- Chưa có số liệu kiểm nghiệm thành phần; chưa có chứng nhận hữu cơ.
- Không kết luận về các chứng nhận khác vì tài liệu không đề cập.